package variable;

import java.net.SocketTimeoutException;

public class example {

	 public static void main(String[] aa)
	 {
		 byte b=100;
		 System.out.println(b);
		 
		
		 short s=100;
		 System.out.println(s);
		
		 
		 int i=100; /// **
		 System.out.println(i);
		
		 long l =3333333;
		 System.out.println(l);
		 
		 //decimal
		 float a =4444.3333333f;
		 System.out.println(a);
		 
		 double d =444444.333333; /// **
		 System.out.println(d);
		 
		 
		 //
		 char c ='2';/// **
		 char dd = '%';
		 char ddd = 'a';
		 System.out.println(c);
		 
		 boolean t = true; /// **
		 System.out.println(t);
		 
		 
		 //
		 String name ="Raman sinha sjshjgwyjrrr"; /// **
		 System.out.println(name);
		 
	 }

}
