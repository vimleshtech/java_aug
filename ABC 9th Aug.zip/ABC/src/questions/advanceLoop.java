package questions;

public class advanceLoop {

	public static void main(String[] args) {

		//array ; collection of similar typedata 
		//multiple values can be stored on single variable
		int n[] = {3333,444,3,2,22,3,44};//array
		
		System.out.println(n[0]);//first element
		//read all
		for(int x: n)
		{
			System.out.println(x);
		}
		

	}

}
