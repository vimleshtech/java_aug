package questions;

import java.net.SocketTimeoutException;
import java.util.Scanner;

public class whileEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=1;  //init / start 
		while(i<=100) //condition 
		{
			//System.out.println(i); //ln : new line
			System.out.print(i); //in same line
			i++;//increment or  i= i+1
		}
		
		//print in reverse 
		i =10;
		while(i>=0)
		{
			System.out.println(i);
			i--;
		}
		
		//print table of 2
		i =2;
		while(i<=20)
		{
			System.out.println(i);
			i+=2; // or i=i+2
			
		}
		//or  print table of 2
		i =1;
		while(i<=10)
		{
			System.out.println(i*2);
			i++;
		}
		
		//print all odd numbers between 1 to 30
		i =1;
		while(i<=30)
		{
			System.out.println(i);
			i+=2;
		}
		
		////wap get sum of all even and odd numbers between 1 to 100
		i=1;
		int se=0,so=0;
		while(i<=100)
		{
			if(i%2==0)
			{
				se =se+i;
			}
			else
			{
				so=so+i;
			}
			i++;
		}
		
		System.out.println("sum of all even :"+se);
		System.out.println("sum of all odd :"+so);
		
		
		////wap to print all numbers between two given no.
		Scanner sc =new Scanner(System.in);
		int n1,n2;
		
		System.out.println("enter first no :");
		n1 = sc.nextInt();
		
		System.out.println("enter end no : ");
		n2= sc.nextInt();
		
		while(n1<=n2)
		{
			System.out.println(n1);
			n1++;
		}
	}

}
