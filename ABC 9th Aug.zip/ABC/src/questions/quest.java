package questions;

import java.util.Scanner;

public class quest {

	public static void main(String[] args) {
	
		String s ="this \nis \tjava\t";
		System.out.println(s);
		
		/*
		int l = s.length();
		String ns = s.replace(" ", "");
		int nl = ns.length();
		
		int sc = l-nl;
		System.out.println(sc);
		*/
		//get count of space
		int sc = s.length() - s.replace(" ","").length();
		System.out.println(sc);
		
		
		//get count of tab
		int tc = s.length() - s.replace("\t","").length();
		System.out.println(tc);
		
		
		//get count of new line
		int nc = s.length() - s.replace("\n","").length();
		System.out.println(nc);
		
				
				
		
				
		

	}

}
