package questions;

public class doWhileEx {

	public static void main(String[] args) {

		//do while : will execute at least one time 
		int i=0;  
		do
		{
			System.out.println(i);
			i++;
		}while(i<0); 

	}

}
