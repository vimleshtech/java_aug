import java.util.Scanner;

/*wap to show count of chars from string
 *wap to show count of word from string 
 *wap to show count of space from string
 *wap to get count of particular word (is?)
 *wap to convert string proper case 
 *wap to show sum of two array of same size
 *wap to show max value from array
 *wap to sort the array
 * 
 */
public class arrayEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name[] ={"raman","jatin","divya","rohit"};

		for(String x: name)
		{
			System.out.println(x);
		}
		
		
		int n[] = new int[4];  //here 4 is size of array
		n[0]  = 1;
		n[1]  = 12;
		n[2]  = 12;
		n[3]  = 13;
		
		for(int x:n)
		{
			System.out.println(x);
		}
		
		//dynaic array
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter size of array : ");		
		int s = sc.nextInt();
		
		int dd[] = new int[s];
		
		for(int i=0; i<s;i++)
		{
			System.out.println("enter data for array: ");
			dd[i] = sc.nextInt();
		}
		
		//outout
		for(int x: dd)
		{
			System.out.println(x);
		}
		
		////2 D Array
		int data[][] = {{11,2,3,4},{33,4,3,3}};  // 2  row * 4 col
		
		//or 
		int aa[][] = new int[2][4];
		aa[0][0] =1;
		aa[0][1] =1;
		aa[0][2] =1;
		aa[0][3] =1;
		
		
		aa[1][0] =1;
		aa[1][1] =1;
		aa[1][2] =1;
		aa[1][3] =1;
		
		//
		for(int x[] : aa)
		{
			for(int x1: x)
			{
				System.out.print(x1+"\t");
			}
			System.out.println();
			
		}
		
		
		
	}

}
