package variable;

public class ifElse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double sales_amt;
		sales_amt =1000;
		
		//if condition 
		if(sales_amt>2000)
		{
			sales_amt=sales_amt*1.18;
			
		}
		else
		{
			//sales_amt=sales_amt*1.05;
			sales_amt=sales_amt+(sales_amt*5)/100;
			
		}
		
		System.out.println("you have to pay : "+sales_amt);
			
		
		
		
	}

}
