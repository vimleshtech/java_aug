package variable;

import java.net.SocketTimeoutException;

public class conditionEx {

	public static void main(String[] args) {

		double sales_amt;
		sales_amt =3000;
		
		//if condition 
		if(sales_amt>2000)
		{
			sales_amt=sales_amt*1.18;
			
		}
		
		System.out.println("you have to pay : "+sales_amt);
			
		
		
		

	}

}
