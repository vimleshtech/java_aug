package variable;

import java.net.SocketTimeoutException;

public class ifelseif {

	public static void main(String[] args) {
	
		int a,b,c;
		a =43;
		b =44;
		c =555;
		
		if(a>b && a>c)
		{
			System.out.println("a is greater");
		}
		else if(b>a && b>c)
		{
			System.out.println("b is greater");
		}
		else
		{
			System.out.println("c is greater");
		}

		
		//nested 
		if(a>b)
		{
			if(a>c)
			{
				System.out.println("a is gt");
			}
			else
			{
				System.out.println("b is gt");
			}
		}
		else
		{
			if(b>c)
			{
				System.out.println("b is gt");
			}
			else
			{
				System.out.println("c is gt");
			}
		}
	}

}
