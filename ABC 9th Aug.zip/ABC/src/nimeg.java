import java.util.Scanner;

public class nimeg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number in Array  ");
		int max ,min;
		int a[][]= new int[2][2];
		for (int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				a[i][j] = sc.nextInt();
			}
		}

		for (int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println(a[i][j]);
			}
		}
		System.out.println("Enter the number in 1D");
		int b[]= new 	int[5];
		for(int i=0;i<5;i++)
		{
			b[i]= sc.nextInt();
		}
		min=b[1];
		max=b[1];
		for(int i=0;i<5;i++)
		{
			if(b[i]>max)
				max=b[i];
		}
		System.out.println("Maximum is "+max);

		for(int i=0;i<5;i++)
		{
			if(b[i]<min)
				min=b[i];
		}
		System.out.println("Minimun number is  "+min);
	}

}
