
public class Myclass {

	public static void main(String[] arg)
	{
		
		int a=2;
		int b=4;
		
		System.out.println("value of c");
		int c = (a+b);
				System.out.println(c);
				
	}
}
