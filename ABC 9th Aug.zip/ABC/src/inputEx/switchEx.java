package inputEx;

import java.util.Scanner;

public class switchEx {

	public static void main(String[] args) {

		Scanner s =new Scanner(System.in);
		int ch,a,b,c=0;
		
		System.out.println("press 1. for add 2. for sub 3. for mul ");
		ch  = s.nextInt();
		
		System.out.println("enter first no : ");
		a =s.nextInt();
		
		System.out.println("enter 2nd  no : ");
		b =s.nextInt();
		
			switch(ch)
			{
				case 1:
					c =a+b;
					break;
				case 2:
					c =a-b;
					break;
				case 3:
					c =a*b;
					break;
				default:
					System.out.println("invalid choice ");
					break;
				
			}

		System.out.println("output = "+c);
		
		
	}

}
