package inputEx;

import java.util.Scanner; //here java.util is package

public class input {

	public static void main(String[] x)
	{
		//here Scanner is inbuilt/system defined class	
		Scanner s =new Scanner(System.in);		
		int a,b,c;
		
		System.out.println("enter first number : ");
		a =s.nextInt();  //input
				

		System.out.println("enter second number : ");
		b =s.nextInt();//input
		
		c =a+b;//logic /expression 
		System.out.println("sum of two numbers : "+c);
		
		
		
		
	}
}
