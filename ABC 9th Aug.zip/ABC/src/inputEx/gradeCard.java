package inputEx;


import java.util.Scanner;

public class gradeCard {

	public static void main(String[] args) {
	
		Scanner sc =new Scanner(System.in);
		
		String sname;
		int sid,hs,es,cs,total;
		double avg;
		
		System.out.println("enter name :");
		sname  = sc.nextLine();
		
		System.out.println("enter sid  :");
		sid = sc.nextInt();
		
		
		System.out.println("enter mark in hindi :");
		hs = sc.nextInt();
		
		System.out.println("enter MARK IN eng. :");
		es= sc.nextInt();
		
		System.out.println("enter mark in compute. :");
		cs = sc.nextInt();
		

		
		total =hs+es+cs;
		avg = total/3;
		System.out.println("Student id :"+sid);
		System.out.println("Student name :"+sname);
		System.out.println("Student total score :"+total);
		System.out.println("Student average score :"+avg);
		
		if(avg>=80)
		{
			System.out.println("Grade A");
		}
		else if(avg>=60)
		{
			System.out.println("Grade B");
		}
		else if(avg>=40)
		{
			System.out.println("Grade C");
		}
		else
		{
			System.out.println("Grade D");
		}
	
	}

}
