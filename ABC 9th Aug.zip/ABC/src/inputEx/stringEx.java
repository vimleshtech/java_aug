package inputEx;

import java.util.Scanner;

public class stringEx {

	public static void main(String[] args) {
		
		String name,ns;
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter string : ");
		name = sc.nextLine();
		
		ns =name.toUpperCase();
		System.out.println(ns);
		
		ns =name.toLowerCase();
		System.out.println(ns);
		
		int l;
		l = name.length();
		System.out.println(l);
		
		
		ns = name.replace("a", "xy");
		System.out.println(ns);
		
		int ps;
		ps = name.indexOf("j");
		System.out.println(ps);
		
		char c;
		c = name.charAt(2);
		System.out.println(c);
		
		
		ns =name.trim();
		System.out.println(ns);
		
		ns =name.substring(2, 6); // 2,3,4,5 = this is java =is i
		System.out.println(ns);
		

		if(name.equals("raman sinha"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		
		//
		if(name.equalsIgnoreCase("raman sinha"))
		{
			System.out.println("match");
		}
		else
		{
			System.out.println("not match");
		}
		//
		if(name.contains("is"))
		{
			System.out.println("is contains");
		}
		else
		{
			System.out.println("is not contains");
		}
		
		//
		if(name.startsWith("ra"))
		{
			System.out.println("start with r");
		}
		else
		{
			System.out.println("not start with ra");
		}
		///
		if(name.endsWith("n"))
		{
			System.out.println("end with n");
		}
		else
		{
			System.out.println("not end with n");
		}
	}
	
	

}
