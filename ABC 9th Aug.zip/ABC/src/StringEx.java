import java.util.Scanner;


public class StringEx {

	public static void main(String[] args) {

		String str,nstr;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter string / text : ");
		str = sc.nextLine();
		
		System.out.println("you have entred : "+str);
		
		nstr = str.toUpperCase();
		System.out.println("you have entred : "+nstr);
		
		nstr = str.toLowerCase();
		System.out.println("you have entred : "+nstr);
		
		int l;
		l = str.length();
		System.out.println("count of chars including space: "+l);	
		
		nstr = str.replace("a", "xy");
		System.out.println(nstr);
		
		nstr = str.substring(2, 10);
		System.out.println(nstr);
		
		//remove extra or leading space : abd   
		nstr = str.trim();
		System.out.println(nstr);

		//return position of char
		int ps;
		ps = str.indexOf("m");
		System.out.println(ps);
		
		
		//return char from given index
		char c= str.charAt(2);
		System.out.println(c);
		
		//convert ascii value 
		int nn = c; 
		char cc =(char) nn;
		
		System.out.println(nn);
		
		///Split : raman kumar sinha ={"raman","kuamr","sinha"}
		String name[] = str.split(" ");
		System.out.println(name[0]);
		
		for(String x: name)
		{
			System.out.println(x);
		}
		
		
		
		//
		if(str.equals("raman sinha"))
		{
			System.out.println("name found");
		}
		else
		{
			System.out.println("name  not found");
		}
		///
		if(str.equalsIgnoreCase("RAMAN sinha"))
		{
			System.out.println("name found");
		}
		else
		{
			System.out.println("name  not found");
		}
		//
		if(str.contains("sin"))
		{
			System.out.println("name found");
		}
		else
		{
			System.out.println("name  not found");
		}
		
		//
		if(str.startsWith("r"))
		{
			System.out.println("start with r");
		}
		else
		{
			System.out.println("didn't start with r");
		}
		
		//
		if(str.endsWith("r"))
		{
			System.out.println("end with r");
		}
		else
		{
			System.out.println("didn't end with r");
		}
		
		
		
		
		
	}

}
