import java.util.Scanner;

public class arrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//array : is collection of data of values 
		//multiple values can be stored on single variable
		//there are following types of array : i. single dimenssion ii. two dimenssion 
		
		int a[] =new int[4];
		a[0]=113;
		a[1]=114;
		a[2]=115;
		a[3]=116;
		
		System.out.println(a[1]);
		System.out.println(a.length);
		
		for(int d: a)
			System.out.println(d);

		
		//
		int dd[] = {111,2,2,3,34,3,3};
		for(int d: dd)
			System.out.println(d);

				
		
		///
		String emp[][] =new String[2][3];
		
		emp[0][0] ="nitin";
		emp[0][1] ="male";
		emp[0][2] ="delhi";
		
		emp[1][0] ="nitin22";
		emp[1][1] ="male33";
		emp[1][2] ="delhi4";
		
		
		System.out.println(emp[1][1]);
		
		for(String row[]:emp)
		{
			for(String c:row)
			{
				System.out.print(c+"\t");
			}
			System.out.println();
		}
		
				
	}

}
