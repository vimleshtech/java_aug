package variable;

public class operatorEx {

	public static void main(String[] aa)
	{
	
		int i,j;
		i = 0;
		j = 0;
		
		System.out.println(i++);//0
		System.out.println(++j);//1
		
		System.out.println(i);//1
		System.out.println(j);//1
		
		///
		i= 2+3*4;
		System.out.println(i);
		
		i= (2+3)*4;
		System.out.println(i);
		
		
	}
}
