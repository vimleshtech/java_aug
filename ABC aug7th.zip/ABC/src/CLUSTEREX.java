import java.util.Scanner;

public class CLUSTEREX {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n[] = {11,2,2,2,23,2,3,3,2,22};
		
		Scanner sc = new Scanner(System.in);
		int c;
		System.out.println("enter no. :");
		c =sc.nextInt();
		
		int t = n.length/c;
		int si =0;
		int li = t;
		
		for(int j=0; j<c;j++)
		{
			for(int i=0; i<n.length;i++)
			{
				if(i>=si && i<li)
				{
					System.out.println("cluster between "+si+" and "+li+"="+n[i]);
				}
			}
			si = li;
			li = li+t;
			
			
		}
		
		
		
		
	}

}
