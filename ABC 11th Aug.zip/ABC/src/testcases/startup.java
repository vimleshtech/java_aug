package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class startup {

	public static void main(String[] args) {
		
		WebDriver driver =new FirefoxDriver();
		driver.get("https://www.google.com/");
		driver.findElement(By.id("lst-ib")).sendKeys("selenium jar download");
		driver.findElement(By.id("lst-ib")).click();
		

	}

}
