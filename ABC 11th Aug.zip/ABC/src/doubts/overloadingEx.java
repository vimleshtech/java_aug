package doubts;

public class overloadingEx {

	public static void main(String[] args) 
	{	

		System.out.println("test ...");
		int o = add(11,2);
		add(11.222,2.3);
		add(o,33,4);
		
		
	}
	public static int add(int a, int b)
	{
		
		int c =a+b;
		//System.out.println("sum of two numbers : "+c);
		return c;
		
	}
	public static void add(int a, int b, int c)
	{
		c =a+b+c;
		System.out.println("sum of three numbers : "+c);
		
	}
	public static void add(double a, double x)
	{
		double  c =a+x;
		System.out.println("sum of two double numbers : "+c);
		
	}

}
