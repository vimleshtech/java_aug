package doubts;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class fileExample {

	public static void main(String[] args) throws IOException {

		//read from file (physical path)
		FileReader  fr = new FileReader ("C:\\Users\\Tech Vision\\Desktop\\myproject\\data.txt");
		//load data to jvm : java virtual memory 
		BufferedReader br  = new BufferedReader(fr);
		
		String s ="";
		//s =  br.nextLine() 
		//Sout(s);

		while( (s =br.readLine() ) !=null)
		{
			System.out.println(s);
		}
		
		br.close();
		fr.close();

	}

}
