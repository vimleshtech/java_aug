package doubts;

import java.sql.DriverManager; //load / register the connector/driver 
import java.sql.Connection;	// establish the connection between java
import java.sql.ResultSet;	//store result of sql command
import java.sql.SQLException;
import java.sql.Statement;  //run sql command 

public class connectionEx {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/learn","root","root");

		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from emp");
		
		while(rs.next())
		{
			System.out.println(rs.getString(1)+"\t"+rs.getString(2));
		}
		

	}

}
