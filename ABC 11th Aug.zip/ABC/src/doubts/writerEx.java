package doubts;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class writerEx {

	public static void main(String[] args) throws IOException {

		
				
				FileWriter  fr = new FileWriter ("C:\\Users\\Tech Vision\\Desktop\\myproject\\data.txt",true);
				//load data to jvm : java virtual memory 
				BufferedWriter br  = new BufferedWriter(fr);

				Scanner sc =new Scanner(System.in);
				String data;
				

				for(int i=0; i<5; i++)
				{
					System.out.println("enter data :");
					data = sc.nextLine();
					br.newLine();
					br.write(data);

				}
				br.close();
				fr.close();
				
	}

}
