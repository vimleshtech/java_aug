package testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class hello {

	public static void main(String[] args) {

		WebDriver driver =new ChromeDriver();
		driver.get("https://www.google.com");
		
		String url = driver.getCurrentUrl();
		System.out.println(url);
		
		String title = driver.getTitle();
		System.out.println(title);
		
		driver.findElement(By.linkText("Gmail")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);		
		driver.findElement(By.linkText("SIGN IN")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);		
		driver.findElement(By.name("identifier")).sendKeys("vimlesh073@gmail.com");		
		driver.findElement(By.id("identifierNext")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);		
		driver.findElement(By.name("password")).sendKeys("fkjhsjgsj");
		driver.findElement(By.id("passwordNext")).click();
		
	}

}
